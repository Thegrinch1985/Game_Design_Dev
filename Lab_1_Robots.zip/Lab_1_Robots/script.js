// Get a reference to the canvas
//Body
var ctx = myCanvas.getContext('2d');
ctx.lineWidth = 2;
ctx.strokeStyle = 'black';
ctx.strokeRect(300,260,140,200);
ctx.stroke();
 //Innerbody 2
var ctx1 = myCanvas.getContext('2d');
ctx1.lineWidth = 2;
ctx1.strokeStyle = 'black';
ctx1.strokeRect(310,280,120,100);
ctx1.stroke();
//inner 1
var ctx2 = myCanvas.getContext('2d');
ctx2.lineWidth = 2;
ctx2.strokeStyle = 'black';
ctx2.strokeRect(325,290,20,80);
ctx2.stroke();
//inner 2
var ctx3 = myCanvas.getContext('2d');
ctx3.lineWidth = 2;
ctx3.strokeStyle = 'black';
ctx3.strokeRect(365,290,20,80);
ctx3.stroke();
//inner 3
var ctx4 = myCanvas.getContext('2d');
ctx4.lineWidth = 2;
ctx4.strokeStyle = 'black';
ctx4.strokeRect(400,290,20,80);
ctx4.stroke();

//diadonal 

var ctx5 = myCanvas.getContext('2d');
ctx5.lineWidth = 2;
ctx5.strokeStyle = 'black';
ctx5.strokeRect(310,400,125,40);
ctx5.stroke();

//square 1 

var ctx6 = myCanvas.getContext('2d');
ctx6.lineWidth = 2;
ctx6.strokeStyle = 'black';
ctx6.strokeRect(320,410,20,20);
ctx6.stroke();

//square 2 
var ctx7 = myCanvas.getContext('2d');
ctx7.lineWidth = 2;
ctx7.strokeStyle = 'black';
ctx7.strokeRect(350,410,20,20);
ctx7.stroke();
//square 3
var ctx8 = myCanvas.getContext('2d');
ctx8.lineWidth = 2;
ctx8.strokeStyle = 'black';
ctx8.strokeRect(380,410,20,20);
ctx8.stroke();
//square 4
var ctx9 = myCanvas.getContext('2d');
ctx9.lineWidth = 2;
ctx9.strokeStyle = 'black';
ctx9.strokeRect(407,410,20,20);
ctx9.stroke();
//pop
var ctx11 = myCanvas.getContext('2d');
ctx11.lineWidth = 2;
ctx11.strokeStyle = 'black';
ctx11.strokeRect(380,100,15,15);
ctx11.stroke();
//pop2
var ctx11 = myCanvas.getContext('2d');
ctx11.lineWidth = 2;
ctx11.strokeStyle = 'black';
ctx11.strokeRect(340,100,15,15);
ctx11.stroke();
//link
var link= myCanvas.getContext('2d');
link.lineWidth = 2;
link.strokeStyle = 'black';
link.strokeRect(344,115,8,45);
link.stroke();

//link
var link2= myCanvas.getContext('2d');
link2.lineWidth = 2;
link2.strokeStyle = 'black';
link2.strokeRect(384,115,8,45);
link2.stroke();
//Head
var Head = myCanvas.getContext('2d');
Head.lineWidth = 2;
Head.strokeStyle = 'black';
Head.strokeRect(320,160,100,100);
Head.stroke();

//eye 1

var eye = myCanvas.getContext('2d');
eye.lineWidth = 2;
eye.strokeStyle = 'black';
eye.strokeRect(380,180,20,20);
eye.stroke();
eye.fillStyle = 'red'
eye.fill();
//eye 2 

var eye2 = myCanvas.getContext('2d');
eye2.lineWidth = 2;
eye2.strokeStyle = 'black';
eye2.strokeRect(340,180,20,20);
eye2.stroke();
//ear1
var ear1 = myCanvas.getContext('2d');
ear1.lineWidth = 2;
ear1.strokeStyle = 'black';
ear1.strokeRect(310,180,10,20);
ear1.stroke();
//ear2

var ear2 = myCanvas.getContext('2d');
ear2.lineWidth = 2;
ear2.strokeStyle = 'black';
ear2.strokeRect(420,180,10,20);
ear2.stroke();
//nose
var nose = myCanvas.getContext('2d');
nose.lineWidth = 2;
nose.strokeStyle = 'black';
nose.strokeRect(365,205,10,10);
nose.stroke();

//mouth
var mouth = myCanvas.getContext('2d');
mouth.beginPath();
mouth.moveTo(340,240);
mouth.lineTo(400,240);
mouth.lineWidth = '5';
mouth.strokeStyle = 'black';
mouth.stroke();

// //lip
// var lip = myCanvas.getContext('2d');
// lip.beginPath();
// mouth.moveTo(340,32);
// lip.lineTo(335,2);
// lip.lineWidth = '5';
// lip.strokeStyle = 'black';
// lip.stroke();

// //lip2
// var lip = myCanvas.getContext('2d');
// lip.beginPath();
// mouth.moveTo(340,32);
// lip.lineTo(335,2);
// lip.lineWidth = '5';
// lip.strokeStyle = 'black';
// lip.stroke();

//arms
var arml= myCanvas.getContext('2d');
arml.lineWidth = 2;
arml.strokeStyle = 'black';
arml.strokeRect(270,265,30,100);
arml.stroke();

var armr3= myCanvas.getContext('2d');
armr3.lineWidth = 2;
armr3.strokeStyle = 'black';
armr3.strokeRect(255,365,45,60);
armr3.stroke();

var armr5= myCanvas.getContext('2d');
armr5.lineWidth = 2;
armr5.strokeStyle = 'black';
armr5.strokeRect(255,365,45,20);
armr5.stroke();
//armr
var armr= myCanvas.getContext('2d');
armr.lineWidth = 2;
armr.strokeStyle = 'black';
armr.strokeRect(440,265,30,100);
armr.stroke();

var armr2= myCanvas.getContext('2d');
armr2.lineWidth = 2;
armr2.strokeStyle = 'black';
armr2.strokeRect(440,365,45,60);
armr2.stroke();

var armr4= myCanvas.getContext('2d');
armr2.lineWidth = 2;
armr2.strokeStyle = 'black';
armr2.strokeRect(440,365,45,20);
armr2.stroke();

//LEG 1
var leg= myCanvas.getContext('2d');
leg.lineWidth = 2;
leg.strokeStyle = 'black';
leg.strokeRect(315,460,45,100);
leg.stroke();

var legb= myCanvas.getContext('2d');
legb.lineWidth = 2;
legb.strokeStyle = 'black';
legb.strokeRect(315,480,45,15);
legb.stroke();

var legc= myCanvas.getContext('2d');
legc.lineWidth = 2;
legc.strokeStyle = 'black';
legc.strokeRect(315,520,45,15);
legc.stroke();

var legd= myCanvas.getContext('2d');
legd.lineWidth = 2;
legd.strokeStyle = 'black';
legd.strokeRect(295, 560,65,25);
legd.stroke();

//leg2

var lege= myCanvas.getContext('2d');
lege.lineWidth = 2;
lege.strokeStyle = 'black';
lege.strokeRect(380,460,45,100);
lege.stroke();

var legf= myCanvas.getContext('2d');
legf.lineWidth = 2;
legf.strokeStyle = 'black';
legf.strokeRect(380,480,45,15);
legf.stroke();

var legg= myCanvas.getContext('2d');
legg.lineWidth = 2;
legg.strokeStyle = 'black';
legg.strokeRect(380,520,45,15);
legg.stroke();

var legh= myCanvas.getContext('2d');
legh.lineWidth = 2;
legh.strokeStyle = 'black';
legh.strokeRect(380, 560,65,25);
legh.stroke();